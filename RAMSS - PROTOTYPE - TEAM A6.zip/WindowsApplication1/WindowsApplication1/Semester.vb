﻿Public Class Semester
End Class
