﻿Public Class Account
    Public prevList As Collection = New Collection
    Public currList As Collection = New Collection
    Public dropCourseForm As DropForm
    Public searchResultsForm As SearchResults

    Private Sub Account_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Semester1.CourseList.View = View.List
        prevList.Add("CPS109")
        prevList.Add("CPS110")
        currList.Add("CPS209")
        currList.Add("CPS310")
        Me.updateCourseList()
        Me.Cart1.CheckedListBox1.CheckOnClick = True
    End Sub
    Private Sub UserControl11_Click(sender As Object, e As EventArgs) Handles UserControl11.Click
        TabControl1.SelectedTab = TabControl1.TabPages.Item(1)
    End Sub

    Private Sub updateCourseList()
        Semester1.CourseList.Items.Clear()
        For Each item In currList
            Semester1.CourseList.Items.Add(item)
        Next
    End Sub

    Private Sub AddCourseBtn_Click(sender As Object, e As EventArgs) Handles AddCourseBtn.Click
        TabControl1.SelectedTab = TabControl1.TabPages.Item(2)
    End Sub

    Private Sub EditCoursesBtn_Click(sender As Object, e As EventArgs) Handles EditCoursesBtn.Click
        dropCourseForm = New DropForm
        For Each item In currList
            dropCourseForm.CheckedListBox1.Items.Add(item)
        Next
        dropCourseForm.CheckedListBox1.CheckOnClick = True
        Dim result As DialogResult = dropCourseForm.ShowDialog(Me)
        If result = DialogResult.Yes Then
            currList = dropCourseForm.updatedCourseList
            Me.updateCourseList()
        ElseIf result = DialogResult.Cancel Then
        End If
    End Sub

    Private Sub CancelSearchBtn_Click(sender As Object, e As EventArgs) Handles CancelSearchBtn.Click
        Me.CourseSearch1.clearSearch()
    End Sub

    Private Sub SrchCourseBtn_Click(sender As Object, e As EventArgs) Handles SrchCourseBtn.Click
        Dim searchResults As Collection = Me.CourseSearch1.searchForCourse()
        searchResultsForm = New SearchResults
        For Each item In searchResults
            searchResultsForm.CheckedListBox1.Items.Add(item)
        Next
        searchResultsForm.CheckedListBox1.CheckOnClick = True
        Dim result As DialogResult = searchResultsForm.ShowDialog(Me)
        If result = DialogResult.Yes Then
            For Each course In searchResultsForm.CheckedListBox1.CheckedItems
                Me.Cart1.CheckedListBox1.Items.Add(course)
            Next
        ElseIf result = DialogResult.Cancel Then
        End If
    End Sub

    Private Sub EnrolBtn_Click(sender As Object, e As EventArgs) Handles EnrolBtn.Click
        Dim coursesToEnroll As Collection = New Collection
        For Each selectedCourse In Me.Cart1.CheckedListBox1.SelectedItems
            coursesToEnroll.Add(selectedCourse)
        Next
        For Each selectedCourse In coursesToEnroll
            currList.Add(selectedCourse)
            Me.Cart1.CheckedListBox1.Items.Remove(selectedCourse)
        Next
        ''TODO: show confirmation of enrollment dialog
        Me.updateCourseList()
    End Sub

    Private Sub RemCartBtn_Click(sender As Object, e As EventArgs) Handles RemCartBtn.Click
        Dim coursesToRemove As Collection = New Collection
        For Each selectedCourse In Me.Cart1.CheckedListBox1.SelectedItems
            coursesToRemove.Add(selectedCourse)
        Next
        For Each selectedCourse In coursesToRemove
            Me.Cart1.CheckedListBox1.Items.Remove(selectedCourse)
        Next
    End Sub

    Private Sub CompleteRegisterBtn_Click(sender As Object, e As EventArgs) Handles CompleteRegisterBtn.Click
        TabControl1.SelectedTab = TabControl1.TabPages.Item(1)
    End Sub

End Class
