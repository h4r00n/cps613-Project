﻿Public Class AcademicProgram
End Class
