﻿Public Class CourseSearch
    Public Sub clearSearch()
        Me.CourseCodeInput.Clear()
        Me.CourceNumInput.Clear()
    End Sub

    Public Function searchForCourse()
        ''TODO: search and return list of courses
        Dim resultCollection As New Collection
        resultCollection.Add("CPS613")
        resultCollection.Add("CPS590")
        Return resultCollection
    End Function
End Class
