﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Account
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.UserControl11 = New WindowsApplication1.AcademicProgram()
        Me.UserControl31 = New WindowsApplication1.FinInfo()
        Me.UserControl21 = New WindowsApplication1.PersInfo()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.AcademicProgram1 = New WindowsApplication1.AcademicProgram()
        Me.GradesSum1 = New WindowsApplication1.GradesSum()
        Me.EditCoursesBtn = New System.Windows.Forms.Button()
        Me.AddCourseBtn = New System.Windows.Forms.Button()
        Me.Semester1 = New WindowsApplication1.Semester()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.CompleteRegisterBtn = New System.Windows.Forms.Button()
        Me.RemCartBtn = New System.Windows.Forms.Button()
        Me.EnrolBtn = New System.Windows.Forms.Button()
        Me.SrchCourseBtn = New System.Windows.Forms.Button()
        Me.CancelSearchBtn = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Cart1 = New WindowsApplication1.Cart()
        Me.CourseSearch1 = New WindowsApplication1.CourseSearch()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Location = New System.Drawing.Point(3, 3)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(619, 604)
        Me.TabControl1.TabIndex = 3
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.UserControl11)
        Me.TabPage1.Controls.Add(Me.UserControl31)
        Me.TabPage1.Controls.Add(Me.UserControl21)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(611, 578)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Home"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'UserControl11
        '
        Me.UserControl11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.UserControl11.Location = New System.Drawing.Point(6, 6)
        Me.UserControl11.Name = "UserControl11"
        Me.UserControl11.Size = New System.Drawing.Size(399, 114)
        Me.UserControl11.TabIndex = 0
        '
        'UserControl31
        '
        Me.UserControl31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.UserControl31.Location = New System.Drawing.Point(6, 256)
        Me.UserControl31.Name = "UserControl31"
        Me.UserControl31.Size = New System.Drawing.Size(399, 121)
        Me.UserControl31.TabIndex = 2
        '
        'UserControl21
        '
        Me.UserControl21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.UserControl21.Location = New System.Drawing.Point(6, 126)
        Me.UserControl21.Name = "UserControl21"
        Me.UserControl21.Size = New System.Drawing.Size(399, 124)
        Me.UserControl21.TabIndex = 1
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.AcademicProgram1)
        Me.TabPage2.Controls.Add(Me.GradesSum1)
        Me.TabPage2.Controls.Add(Me.EditCoursesBtn)
        Me.TabPage2.Controls.Add(Me.AddCourseBtn)
        Me.TabPage2.Controls.Add(Me.Semester1)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(611, 578)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Academic Program"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'AcademicProgram1
        '
        Me.AcademicProgram1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.AcademicProgram1.Location = New System.Drawing.Point(3, 6)
        Me.AcademicProgram1.Name = "AcademicProgram1"
        Me.AcademicProgram1.Size = New System.Drawing.Size(402, 132)
        Me.AcademicProgram1.TabIndex = 5
        '
        'GradesSum1
        '
        Me.GradesSum1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.GradesSum1.Location = New System.Drawing.Point(6, 422)
        Me.GradesSum1.Name = "GradesSum1"
        Me.GradesSum1.Size = New System.Drawing.Size(399, 84)
        Me.GradesSum1.TabIndex = 4
        '
        'EditCoursesBtn
        '
        Me.EditCoursesBtn.Location = New System.Drawing.Point(269, 371)
        Me.EditCoursesBtn.Name = "EditCoursesBtn"
        Me.EditCoursesBtn.Size = New System.Drawing.Size(127, 34)
        Me.EditCoursesBtn.TabIndex = 3
        Me.EditCoursesBtn.Text = "Edit Current Courses"
        Me.EditCoursesBtn.UseVisualStyleBackColor = True
        '
        'AddCourseBtn
        '
        Me.AddCourseBtn.Location = New System.Drawing.Point(17, 371)
        Me.AddCourseBtn.Name = "AddCourseBtn"
        Me.AddCourseBtn.Size = New System.Drawing.Size(127, 34)
        Me.AddCourseBtn.TabIndex = 2
        Me.AddCourseBtn.Text = "Add Course"
        Me.AddCourseBtn.UseVisualStyleBackColor = True
        '
        'Semester1
        '
        Me.Semester1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Semester1.Location = New System.Drawing.Point(6, 144)
        Me.Semester1.Name = "Semester1"
        Me.Semester1.Size = New System.Drawing.Size(399, 272)
        Me.Semester1.TabIndex = 1
        '
        'TabPage3
        '
        Me.TabPage3.AutoScroll = True
        Me.TabPage3.Controls.Add(Me.CompleteRegisterBtn)
        Me.TabPage3.Controls.Add(Me.RemCartBtn)
        Me.TabPage3.Controls.Add(Me.EnrolBtn)
        Me.TabPage3.Controls.Add(Me.SrchCourseBtn)
        Me.TabPage3.Controls.Add(Me.CancelSearchBtn)
        Me.TabPage3.Controls.Add(Me.Label1)
        Me.TabPage3.Controls.Add(Me.Cart1)
        Me.TabPage3.Controls.Add(Me.CourseSearch1)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(611, 578)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Course Registration"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'CompleteRegisterBtn
        '
        Me.CompleteRegisterBtn.Location = New System.Drawing.Point(275, 447)
        Me.CompleteRegisterBtn.Name = "CompleteRegisterBtn"
        Me.CompleteRegisterBtn.Size = New System.Drawing.Size(127, 36)
        Me.CompleteRegisterBtn.TabIndex = 7
        Me.CompleteRegisterBtn.Text = "Finish Enrolling"
        Me.CompleteRegisterBtn.UseVisualStyleBackColor = True
        '
        'RemCartBtn
        '
        Me.RemCartBtn.Location = New System.Drawing.Point(275, 387)
        Me.RemCartBtn.Name = "RemCartBtn"
        Me.RemCartBtn.Size = New System.Drawing.Size(111, 36)
        Me.RemCartBtn.TabIndex = 6
        Me.RemCartBtn.Text = "Remove Selected Course(s)"
        Me.RemCartBtn.UseVisualStyleBackColor = True
        '
        'EnrolBtn
        '
        Me.EnrolBtn.Location = New System.Drawing.Point(17, 387)
        Me.EnrolBtn.Name = "EnrolBtn"
        Me.EnrolBtn.Size = New System.Drawing.Size(111, 36)
        Me.EnrolBtn.TabIndex = 5
        Me.EnrolBtn.Text = "Enroll in Selected Course(s)"
        Me.EnrolBtn.UseVisualStyleBackColor = True
        '
        'SrchCourseBtn
        '
        Me.SrchCourseBtn.Location = New System.Drawing.Point(275, 139)
        Me.SrchCourseBtn.Name = "SrchCourseBtn"
        Me.SrchCourseBtn.Size = New System.Drawing.Size(111, 36)
        Me.SrchCourseBtn.TabIndex = 3
        Me.SrchCourseBtn.Text = "Search"
        Me.SrchCourseBtn.UseVisualStyleBackColor = True
        '
        'CancelSearchBtn
        '
        Me.CancelSearchBtn.Location = New System.Drawing.Point(17, 139)
        Me.CancelSearchBtn.Name = "CancelSearchBtn"
        Me.CancelSearchBtn.Size = New System.Drawing.Size(111, 36)
        Me.CancelSearchBtn.TabIndex = 2
        Me.CancelSearchBtn.Text = "Cancel"
        Me.CancelSearchBtn.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(3, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(174, 24)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Course Registration"
        '
        'Cart1
        '
        Me.Cart1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Cart1.Location = New System.Drawing.Point(7, 194)
        Me.Cart1.Name = "Cart1"
        Me.Cart1.Size = New System.Drawing.Size(425, 247)
        Me.Cart1.TabIndex = 4
        '
        'CourseSearch1
        '
        Me.CourseSearch1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.CourseSearch1.Location = New System.Drawing.Point(7, 27)
        Me.CourseSearch1.Name = "CourseSearch1"
        Me.CourseSearch1.Size = New System.Drawing.Size(425, 161)
        Me.CourseSearch1.TabIndex = 1
        '
        'TabPage4
        '
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(611, 578)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Grades"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'TabPage5
        '
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(611, 578)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Graduation"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'Account
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "Account"
        Me.Size = New System.Drawing.Size(625, 485)
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents UserControl11 As AcademicProgram
    Friend WithEvents UserControl21 As PersInfo
    Friend WithEvents UserControl31 As FinInfo
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents TabPage5 As TabPage
    Friend WithEvents Semester1 As Semester
    Friend WithEvents EditCoursesBtn As Button
    Friend WithEvents AddCourseBtn As Button
    Friend WithEvents GradesSum1 As GradesSum
    Friend WithEvents Label1 As Label
    Friend WithEvents CourseSearch1 As CourseSearch
    Friend WithEvents SrchCourseBtn As Button
    Friend WithEvents CancelSearchBtn As Button
    Friend WithEvents RemCartBtn As Button
    Friend WithEvents EnrolBtn As Button
    Friend WithEvents Cart1 As Cart
    Friend WithEvents CompleteRegisterBtn As Button
    Friend WithEvents AcademicProgram1 As AcademicProgram
    Public WithEvents TabControl1 As TabControl
End Class
