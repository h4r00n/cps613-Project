﻿Public Class GradesSum

End Class
