﻿Public Class SearchResults
    Public selectedCourseList As Collection = New Collection
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim coursesToRemove As Collection = New Collection
        For Each selectedCourse In CheckedListBox1.CheckedItems
            coursesToRemove.Add(selectedCourse)
        Next

        For Each course In CheckedListBox1.Items
            selectedCourseList.Add(course)
        Next
    End Sub
End Class